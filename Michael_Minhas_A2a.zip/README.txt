Michael Minhas 
A00961026

A2a COMP 2526 Chess Game. 

Didn't use any pictures, just the string to distinguish
between pieces. Also implemented turns for the upcoming
assignment. Starting working on validating moves but didn't 
get far in doing so. Folder also contains an executable
jar file for the Chess Game. 