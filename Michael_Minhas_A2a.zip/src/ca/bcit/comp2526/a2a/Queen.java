package ca.bcit.comp2526.a2a;

/**
 * Child of the Piece class. Uses it's constructor to instantiate a Queen on the
 * Chess Board with a specific String.
 * 
 * @author Michael Minhas
 *
 */
public class Queen extends Piece {

    /**
     * Constructor - instantiates a Queen object for the specified player.
     * 
     * @param currentPlayer
     *            one of the two players
     */
    protected Queen(Player currentPlayer) {
        super(currentPlayer, "Q");
    }

    /**
     * Checks if the move for the piece is valid or not.
     * 
     * @return true if valid, false otherwise
     */
    public boolean isValidMove(Square paramSquare, Board paramBoard) {
        return true;
    }

}
