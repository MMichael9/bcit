package ca.bcit.comp2526.a2a;

/**
 * Child of the Piece class. Uses it's constructor to instantiate a Knight on
 * the Chess Board with a specific String.
 * 
 * @author Michael Minhas
 *
 */
public class Knight extends Piece {

    /**
     * Constructor - instantiates a Knight object for the specified player.
     * 
     * @param currentPlayer
     *            one of the two players
     */
    protected Knight(Player currentPlayer) {
        super(currentPlayer, "Kn");
    }

    /**
     * Checks if the move for the piece is valid or not.
     * 
     * @return true if valid, false otherwise
     */
    public boolean isValidMove(Square paramSquare, Board paramBoard) {
        return true;
    }

}
