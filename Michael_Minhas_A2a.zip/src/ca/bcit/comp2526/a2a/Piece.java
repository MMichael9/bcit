package ca.bcit.comp2526.a2a;

/**
 * Class which represents all the possible Chess pieces. The various pieces make
 * reference to the constructor of the Piece class as it instantiates a string
 * to represent each piece based on the type of piece and owner.
 * 
 * @author Michael Minhas
 *
 */
public abstract class Piece {

    private final String type;
    private final Player owner;
    private Square square;
    
    /**
     * Constructor - Assigns the type of piece to the specified player. String
     * is dependent on the type of piece.
     * 
     * @param player
     *            specified player
     * @param piece
     *            specified type
     */
    protected Piece(Player player, String piece) {
        this.owner = player;
        this.type = piece;
    }


    /**
     * Returns type of piece.
     * 
     * @return type of piece
     */
    public String getType() {
        return type;
    }

    /**
     * Returns the player.
     * 
     * @return the requested player of a piece
     */
    public Player getPlayer() {
        return owner;
    }
    
    /**
     * Set square of a piece.
     * 
     * @param square specified square for the piece 
     */
    public void setSquare(Square square) {
        square = this.square;
    }

    public abstract boolean isValidMove(Square clickSquare, Board board);
}
