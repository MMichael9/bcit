package ca.bcit.comp2526.a2a;

/**
 * Child of the Piece class. Uses it's constructor to instantiate a King on the
 * Chess Board with a specific String.
 * 
 * @author Michael Minhas
 *
 */
public class King extends Piece {

    /**
     * Constructor - instantiates a King object for the specified player.
     * 
     * @param currentPlayer
     *            one of the two players
     */
    protected King(Player currentPlayer) {
        super(currentPlayer, "K");
    }

    /**
     * Checks if the move for the piece is valid or not.
     * 
     * @return true if valid, false otherwise
     */
    public boolean isValidMove(Square paramSquare, Board paramBoard) {
        return true;
    }

}
