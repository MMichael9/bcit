package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.awt.Rectangle;

import javax.swing.JFrame;

/**
 * Chess game using a GUI which creates, formats and displays a board filled
 * with the correct chess pieces to simulate a real game. The game consists of
 * the regular 16 pieces that each player starts off with and continues on until
 * the user closes the window. The build as of now has turns implemented but
 * allows for piece movement to any position on the board. This is the main
 * driver class for the program as this acts as the brain for the game as a
 * whole.
 * 
 * @author Michael Minhas A00961026
 *
 */
public class Chess extends JFrame {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    private final Board board;
    private final Player playerOne = new Player(Color.RED);
    private final Player playerTwo = new Player(Color.BLUE);
    private Player currentPlayer;

    /**
     * <p>
     * This is the main method (entry point) that gets called by the JVM.
     * </p>
     *
     * @param args
     *            command line arguments.
     */
    public static void main(String[] args) {
        Chess chessGame = new Chess();
        chessGame.createBoard();
        chessGame.formatBoard();
        chessGame.createPieces();
    }

    /**
     * Constructor - Creates a frame to store all the components as well as
     * instantiates the Board for the game.
     */
    public Chess() {
        super("Michael Minhas Chess Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(board = new Board(8, 8));
        setVisible(true);
    }

    /**
     * Creates the board and adds a listener to it for the purpose of finding
     * where the user clicks. Also sets the player who will take their turn
     * first.
     */
    public void createBoard() {
        this.board.createBoard(new MouseListener(this));
        currentPlayer = playerTwo;
    }

    /**
     * Formats the board. Without this the JFrame will not update unless the
     * window is resized. Positions the GUI on the screen as well as gives the
     * Chess Board a suitable size to play on.
     */
    private void formatBoard() {
        Rectangle gameBoard = new Rectangle(400, 100, 700, 700);
        setBounds(gameBoard);
    }

    /**
     * Instantiate and create the pieces of a normal Chess board. Gives each
     * player the correct pieces as well as where the piece will be on the
     * board.
     */
    public void createPieces() {
        setPiece(0, 0, new Rook(playerOne));
        setPiece(0, 1, new Knight(playerOne));
        setPiece(0, 2, new Bishop(playerOne));
        setPiece(0, 3, new Queen(playerOne));
        setPiece(0, 4, new King(playerOne));
        setPiece(0, 5, new Bishop(playerOne));
        setPiece(0, 6, new Knight(playerOne));
        setPiece(0, 7, new Rook(playerOne));
        for (int i = 0; i < board.getColumns(1); i++) {
            setPiece(1, i, new Pawn(playerOne));
        }

        setPiece(7, 0, new Rook(playerTwo));
        setPiece(7, 1, new Knight(playerTwo));
        setPiece(7, 2, new Bishop(playerTwo));
        setPiece(7, 3, new Queen(playerTwo));
        setPiece(7, 4, new King(playerTwo));
        setPiece(7, 5, new Bishop(playerTwo));
        setPiece(7, 6, new Knight(playerTwo));
        setPiece(7, 7, new Rook(playerTwo));
        for (int j = 0; j < board.getColumns(6); j++) {
            setPiece(6, j, new Pawn(playerTwo));
        }
    }

    /**
     * Sets a piece at a specified square based on the input parameters.
     * 
     * @param row
     *            row on the board
     * @param column
     *            column on the board
     * @param piece
     *            type of pecee being set
     */
    public void setPiece(int row, int column, Piece piece) {
        board.getSquare(row, column).setPiece(piece);
    }

    /**
     * return the current player to see whose turn it is.
     * 
     * @return Player whose turn it is
     */
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    /**
     * Returns the Board.
     * 
     * @return board of the Chess game
     */
    public Board getBoard() {
        return board;
    }

    /**
     * Move a Chess piece from one location to another.
     * 
     * @param currentSquare
     *            square the piece starts at
     * @param locationSquare
     *            destination square
     */
    public void move(Square currentSquare, Square locationSquare) {
        Piece clickPiece = currentSquare.getPiece();
        currentSquare.setPiece(null);
        locationSquare.setPiece(clickPiece);
        currentSquare.repaint();
        locationSquare.repaint();
    }

    /**
     * Switch players to simulate turns.
     */
    public void switchPlayers() {
        if (currentPlayer == playerTwo) {
            currentPlayer = playerOne;
        } else {
            currentPlayer = playerTwo;
        }
    }
}
