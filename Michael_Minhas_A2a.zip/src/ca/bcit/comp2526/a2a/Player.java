package ca.bcit.comp2526.a2a;

import java.awt.Color;

/**
 * Distinguishes each player by a specified color which is assigned to each
 * piece for showcasing.
 * 
 * @author Michael Minhas
 *
 */
public class Player {
    public final Color colour;

    /**
     * Constructor - initializes pieces using the specified colour.
     * 
     * @param colour
     *            specified colour representing a player
     */
    public Player(Color colour) {
        this.colour = colour;
    }
}
