package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;

/**
 * Creates a Board that is used for the Chess game simulation. Given dimensions,
 * the Board is created and formatted to the correct specifications. They are
 * added to the JFrame and each Square that is implemented is equipped with it's
 * own mouse listener.
 * 
 * @author Michael Minhas
 *
 */
public class Board extends JPanel {

    /**
     * serialVersionUID. 
     */
    private static final long serialVersionUID = 1L;
    public final Square[][] squares;

    /**
     * Constructor - Receives the length and width for the dimensions of the
     * Board.
     * 
     * @param length
     *            length of Board
     * @param width
     *            width of Board
     */
    public Board(int length, int width) {
        squares = new Square[length][width];
    }

    /**
     * Using a GridLayout, creates the board and fills it with squares (8x8).
     * Adds a listener to the squares and colours each square accordingly.
     * 
     * @param listener
     *            mouse lisenter for the squares
     */
    public void createBoard(MouseListener listener) {
        setLayout(new GridLayout(squares.length, squares[0].length));
        for (int i = 0; i < squares.length; i++) {
            for (int j = 0; j < squares[0].length; j++) {
                if ((i + j) % 2 == 0) {
                    squares[i][j] = new Square(i, j, (new Color(255, 206, 105)));
                } else {
                    squares[i][j] = new Square(i, j, (new Color(186, 124, 0)));
                }
                add(squares[i][j]);
                squares[i][j].addMouseListener(listener);
            }
        }
    }

    /**
     * Return the square at the specified point.
     * 
     * @param row
     *            specified row
     * @param column
     *            specified column
     * 
     * @return square at the specified position
     */
    public Square getSquare(int row, int column) {
        return squares[row][column];
    }

    /**
     * Return number of columns.
     * 
     * @param col
     *            position on the board
     * @return number of columns
     */
    public int getColumns(int col) {
        return squares[col].length;
    }
}
