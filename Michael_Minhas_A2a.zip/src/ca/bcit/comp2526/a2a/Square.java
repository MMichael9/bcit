package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

/**
 * Squares are colored, depending on the specified row and column and then added
 * to the Board through the Board class. Checks if a square is occupied by a
 * piece object for the purpose of moving pieces.
 * 
 * @author Michael Minhas
 *
 */
public class Square extends JPanel {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    private int row;
    private int column;
    private Piece piece;
    private boolean occupied;

    /**
     * Constructor - instantiates a Square object at a specified location with
     * the designated colour.
     * 
     * @param row
     *            row for the square position
     * @param column
     *            column for the square position
     * @param colour
     *            colour of the square
     */
    public Square(int row, int column, Color colour) {
        this.row = row;
        this.column = column;
        setBackground(colour);
    }

    /**
     * Paints and styles the String based on the type of piece that it is.
     */
    public void paint(Graphics page) {
        super.paint(page);
        if (piece != null) {
            page.setFont(new Font("Sans", Font.BOLD, 25));
            page.setColor(piece.getPlayer().colour);
            page.drawString(piece.getType(), 35, 50);
        }
    }

    /**
     * Sets a piece object to a specified piece based on the parameter given.
     * 
     * @param newPiece
     *            new piece that is to be set
     */
    public void setPiece(Piece newPiece) {
        if (piece != null) {
            piece.setSquare(null);
        }
        piece = newPiece;
        if (piece != null) {
            piece.setSquare(this);
        }
    }

    /**
     * returns the current piece object in the square.
     * 
     * @return current piece object
     */
    public Piece getPiece() {
        return piece;
    }

    /**
     * Returns the row of the square object.
     * 
     * @return row of object
     */
    public int getRow() {
        return row;
    }

    /**
     * Returns column of the square object.
     * 
     * @return column of object
     */
    public int getColumn() {
        return column;
    }

    /**
     * Checks whether a square is occupied given a parameter.
     * 
     * @param occupied
     *            true or false depending on the parameter passed
     */
    public void isOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    /**
     * Returns the value of occupied.
     * 
     * @return true or false depending on value
     */
    public boolean returnOccupied() {
        return occupied;
    }
}
