package ca.bcit.comp2526.a2a;

/**
 * Child of the Piece class. Uses it's constructor to instantiate a Bishop on
 * the Chess Board with the specified String
 * 
 * @author Michael Minhas
 *
 */
public class Bishop extends Piece {

    /**
     * Constructor - instantiates a Bishop object for the specified player.
     * 
     * @param currentPlayer
     *            one of the two players
     */
    protected Bishop(Player currentPlayer) {
        super(currentPlayer, "B");
    }
    
    /**
     * Returns true if a move is valid, otherwise returns false. 
     * 
     * @return true if valid, false otherwise
     */
    public boolean isValidMove(Square paramSquare, Board paramBoard) {
        return true;
    }
}
