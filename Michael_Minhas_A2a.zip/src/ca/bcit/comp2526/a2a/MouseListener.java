package ca.bcit.comp2526.a2a;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Listens for clicks on squares on the Chess Board. Simulates all the movement
 * for the chess pieces based on the specified conditions.
 * 
 * @author Michael Minhas
 *
 */
public class MouseListener extends MouseAdapter {

    private final Chess chessGame;
    private Square currentSquare;

    /**
     * Initializes the Chess game.
     * 
     * @param game
     *            Current Chess game
     */
    public MouseListener(Chess game) {
        chessGame = game;
    }

    /**
     * On mouse clicks, if it is the players turn, pieces can be moved to any
     * position on the board. Depending on where the player clicks, the piece is
     * essentially painted atop the other piece showcasing a piece moving.
     */
    public void mouseClicked(MouseEvent paramMouseEvent) {
        Square clickSquare = (Square) paramMouseEvent.getSource();
        Piece attacker;
        if (currentSquare == null) {
            attacker = clickSquare.getPiece();
            if ((attacker != null) && (attacker.getPlayer() == this.chessGame.getCurrentPlayer())) {
                currentSquare = clickSquare;
                currentSquare.isOccupied(true);
                currentSquare.repaint();
            }
        } else {
            attacker = clickSquare.getPiece();
            Piece defender = currentSquare.getPiece();
            if ((attacker != null) && (defender.getPlayer() == attacker.getPlayer())) {
                currentSquare.isOccupied(false);
                currentSquare.repaint();
                currentSquare = clickSquare;
                currentSquare.isOccupied(true);
                currentSquare.repaint();
            } else if (defender.isValidMove(clickSquare, this.chessGame.getBoard())) {
                chessGame.move(this.currentSquare, clickSquare);
                currentSquare.isOccupied(false);
                currentSquare.repaint();
                currentSquare = null;
                chessGame.switchPlayers();
            }
        }
    }
}
