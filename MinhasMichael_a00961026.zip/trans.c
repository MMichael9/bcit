#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define LINESIZE 1024
#define MAXSIZE 512

/*
Methods to be used
*/
void escapechar(char set[]);
void expandchar(char set[]);
int check_range(char x, char y);
void truncate_sets(char set1[], char set2[]);
void extend_set(char set1[], char set2[]);
void get_input(const char set1[], const char set2[]);
int is_last_char(const char set[], char c, size_t i );

/*
Main method. Entry point of program. Gets command line arguments
and passes them to specified functions. 
*/
int main(int argc, char *argv[]) {
	char set1[LINESIZE];
	char set2[LINESIZE];
	
	if(argc < 3 || argc > 4)
		exit(1);
	
	if (strcmp(argv[1],"-e") == 0) {
		int set1_len;
		int set2_len;
		strcpy(set1,argv[2]);
		strcpy(set2,argv[3]);
		escapechar(set1);
		escapechar(set2);
		expandchar(set1);
		expandchar(set2);
		set1_len = strlen(set1);
		set2_len = strlen(set2);
		if (set1_len > set2_len) {
			extend_set(set1, set2);
		}
		else { 
			truncate_sets(set1, set2);
		}
		get_input(set1, set2);
	}
	
	else {
		strcpy(set1,argv[1]);
		strcpy(set2,argv[2]);
		escapechar(set1);
		escapechar(set2);
		expandchar(set1);
		expandchar(set2);
		truncate_sets(set1, set2);
		get_input(set1, set2);
	}
	
	
	
	return 0;
}

/*
Determines if a charachter in a set of charachters given is a 
escape character. If it is, the specified escape charachter is 
inserted into the set array. 
*/
void escapechar(char set[]) {
	int i,j;
	
	for (i = 0, j = 0; set[i] != '\0'; i++, j++) {
		if (set[i] == '\\' && set[i+1] !='\0') {
			switch(set[i+1]) {
				case '\\': 
					set[j] = '\\';
					break;
				case 'a' :
					set[j] = '\a';
					break;
				case 'b' :
					set[j] = '\b';
					break;
				case 'f' :
					set[j] = '\f';
					break;
				case 'n' :
					set[j] = '\n';
					break;
				case 'r' :
					set[j] = '\r';
					break;				
				case 't' :
					set[j] = '\t';
					break;
				case 'v' :
					set[j] = '\v';
					break;
				case '\'':
					set[j] = '\'';
					break;
				case '\"':
					set[j] = '\"';
					break;
				default  :
					printf("INVALID !");
					exit(1);
			}
			i+=1;
		}
		else {
			set[j] = set[i];
		}
	}
	set[j] = '\0';
}

/*
If a set entered contains a range of charachters such as 'a-c', it is 
exapnded to 'abc'. the expanded charachters are the set to array passed 
to the function. 
*/
void expandchar(char set[]) {
	int i, j;
	char tmp[LINESIZE];
	int len = strlen(set);
	int special = 1;
	
	for(i = 0, j = 0; set[i] != '\0'; i++) {
		if (set[i] == '-') {
			if ((i == 0) || (i == len - 1)) {
				tmp [j++] = set[i];
			}
			else if (special == 1) {
				char x = set[i - 1];
				char y = set[i + 1];
				j = j - 1;
				if (x <= y) {
					for ( ; x <= y;) {
						tmp[j++] = (char)(x);
						x++;
					}
				}
				else {
					exit(1);
				}
				special = -1;
				j = j - 1;
			}
			else {
				tmp[j++] = set[i];
				special = 1;
			}
		}
		else {
			tmp[j++] = set[i];
		} 
			
	}
	tmp[j] = '\0';
	
	
	if ((strlen(tmp)) > MAXSIZE)
		exit(1);
	
	strcpy(set, tmp);
}

/*
Checks if the range given is valid or not. If a range such as 
'c-a' is entered, it is treated as invalid and thus will be 
returned as false (0). 
*/
int check_range(char x, char y) {
	if (x <= y) {
		return 1;
	}
	else 
		return 0;
}

/*
Truncates a set if one of the input sets are larger than the other. The larger set 
is cut off so it can line up with the smaller set
*/
void truncate_sets(char set1[], char set2[]) {
	int x = strlen(set1);
	int y = strlen(set2);
	
	if (x > y) {
		set1[y] = '\0';
	}
	
	if (x < y) {
		set2[x] = '\0';
	}
}

/*
Activated if '-e' is passed as one of the command line arguments and if 
set1 is larger than set2. Using the last charachter in set2, the set will be
expanded to the length of set1 using that last charachter.
*/
void extend_set(char set1[], char set2[]) {
	int set2_len = strlen(set2);
	int set1_len = strlen(set1);
	char last_char = set2[set2_len - 1];
	int i = set2_len;	
	
	while (i < set1_len) {
		set2[i] = last_char;
		i++;
	}
	set2[i] = '\0';
}

/*
Get input from the user. Using the two sets, translates the input based 
on the sets entered. 
*/
void get_input(const char set1[], const char set2[]) {
	int c;
	int i;
	int print;
	while ((c = getchar()) != EOF) {
		print = 0;
		
		for (i = 0; set1[i] != '\0'; i++) {
			if (c == set1[i] && ((is_last_char(set1, set1[i], i)) == 1)) {
				putchar(set2[i]);
				print = 1;
			}
		}
		if (print == 0) {
			putchar(c);
		}
	}
}

/*
Determines if a charachter in the first set is the last of 
that charachter in the set. If it isn't false is returned
otherwise return 0. 
*/
int is_last_char(const char set[], char c, size_t j) {
	size_t i;
	for (i = 0; set[i] != '\0';i++) {
		if (i > j && set[i] == c)
			return 0;
	}
	return 1;
}